## v2.1 — Full Electric Blue Liquid Glass & Responsive Fix
- Menerapkan Liquid Glass biru elektrik secara menyeluruh pada permukaan aplikasi, panel, form, ringkasan, keranjang, dialog, dan tombol.
- Menghilangkan sisa permukaan hitam/abu-abu dari tema lama pada tampilan utama.
- Memperbaiki aturan lebar responsif untuk mencegah layout utama menyempit atau melebar di Android WebView.
- Mempertahankan logika kasir, riwayat, backup/restore, logo, ikon pangkat, dan alur build Android.

# Changelog — Vyn Store Ultimate Edition 2.0

## Tampilan
- Penyempurnaan Liquid Glass dengan Colorful Blur, Electric Blue, dan aksen Silver.
- Dashboard ringkasan toko dengan panel kaca.
- Komponen riwayat dan nota arsip mengikuti gaya visual aplikasi.
- Ikon antarmuka berupa SVG lokal; tidak memerlukan CDN atau koneksi internet.
- Penyesuaian layout untuk layar ponsel dan tablet.

## Fitur baru
- Keranjang dan nama pelanggan dipulihkan otomatis dari penyimpanan lokal.
- Simpan transaksi ke riwayat lokal (maksimal 500 transaksi terbaru).
- Pencarian, detail nota, dan penghapusan transaksi.
- Dashboard omzet hari ini, jumlah transaksi, dan akumulasi omzet.
- Ekspor CSV riwayat.
- Backup JSON dan pemulihan dari file JSON.
- Tombol kembali Android menutup modal sebelum keluar dari aplikasi.

## Yang tidak diubah
- Rumus kalkulator pangkat reguler dan Bintang.
- Tarif V, Diamond, Major, dan Bintang pada proyek v5.
- Logo Vyn Store dan aset emblem pangkat.
