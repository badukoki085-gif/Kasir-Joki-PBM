# Kasir Joki Pangkat PB — Android

Aplikasi Android WebView yang memuat aplikasi kasir HTML lokal. Tidak membutuhkan koneksi internet saat digunakan dan tidak meminta izin internet.

## Cara menghasilkan APK melalui GitHub Actions
1. Buat repository GitHub baru.
2. Upload seluruh isi folder proyek ini (bukan file ZIP-nya) ke repository.
3. Buka tab **Actions** dan pilih workflow **Build Android APK**.
4. Klik **Run workflow** (atau tunggu build otomatis setelah push ke branch `main`).
5. Setelah status selesai, buka hasil workflow dan unduh artifact **Kasir-Joki-PB-APK**.
6. Ekstrak ZIP artifact, lalu pasang `app-debug.apk` di HP Android. Jika diminta, izinkan instalasi dari sumber tersebut.

## Persyaratan
- Android 6.0 (API 23) atau lebih baru.
- Build membutuhkan koneksi internet di GitHub Actions untuk mengunduh Android Gradle Plugin dan Android SDK. Aplikasi yang sudah terpasang berjalan offline.

## Catatan
APK debug cocok untuk instalasi pribadi/testing. Untuk distribusi luas atau Play Store, buat APK/AAB release yang ditandatangani dengan keystore milik sendiri.
