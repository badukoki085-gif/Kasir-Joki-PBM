# Vyn Store — Kasir Joki PB Ultimate Edition

Aplikasi Android offline berbasis WebView untuk kalkulator dan kasir joki pangkat Point Blank. Seluruh UI, kalkulasi, riwayat, dan penyimpanan data berjalan lokal di perangkat.

## Fitur
- Kalkulator pangkat reguler (V, Diamond, Major), mode rentang dan manual.
- Kalkulator pangkat Bintang berbasis EXP.
- Keranjang transaksi dengan pemulihan otomatis setelah aplikasi dibuka ulang.
- Nota/struk, salin teks, dan arsip transaksi.
- Dashboard omzet hari ini, jumlah transaksi, dan total omzet.
- Pencarian, detail, penghapusan, serta ekspor CSV riwayat.
- Backup JSON dan pemulihan data dari file backup.
- Antarmuka Liquid Glass biru elektrik/silver, responsif untuk HP dan tablet.
- Tidak membutuhkan koneksi internet untuk fungsi utama.

## Build APK
Dari folder proyek: `gradle assembleDebug`. APK berada di `app/build/outputs/apk/debug/app-debug.apk`. GitHub Actions juga membangun APK pada push ke branch main atau workflow dispatch.

## Penyimpanan data
Data transaksi disimpan pada localStorage WebView di perangkat. Backup JSON dapat dibuat dari menu Riwayat. Pada APK, file backup disimpan di folder Documents milik aplikasi (`Android/data/id.vynstore.kasirjokipb/files/Documents`). Buat backup sebelum menghapus aplikasi atau membersihkan data aplikasi.
