# Changelog

## Update 2.3 – Gemini UI Integration
- Mengganti tampilan WebView dengan desain Liquid Glass dari HTML terbaru.
- Mempertahankan struktur proyek Android, launcher, dan logo VYN Store.
- Mengaktifkan izin INTERNET untuk Tailwind, Lucide, Google Fonts, dan html2canvas melalui HTTPS.
- Menambahkan penanganan tombol Back Android untuk menutup modal terlebih dahulu.

v2.1 — Full Electric Blue Liquid Glass & Responsive Fix
- Menerapkan Liquid Glass biru elektrik secara menyeluruh pada permukaan aplikasi, panel, form, ringkasan, keranjang, dialog, dan tombol.
- Menghilangkan sisa permukaan hitam/abu-abu dari tema lama pada tampilan utama.
- Memperbaiki aturan lebar responsif untuk mencegah layout utama menyempit atau melebar di Android WebView.
- Mempertahankan logika kasir, riwayat, backup/restore, logo, ikon pangkat, dan alur build Android.

# Changelog — Vyn Store Ultimate Edition 2.0

## Tampilan
- Penyempurnaan Liquid Glass dengan Colorful Blur, Electric Blue, dan aksen Silver.
- Dashboard ringkasan toko dengan panel kaca.
- Komponen riwayat dan nota arsip mengikuti gaya visual aplikasi.
- Ikon antarmuka berupa SVG lokal; tidak memerlukan CDN atau koneksi internet.
- Penyesuaian layout untuk layar ponsel dan tablet.

## Fitur baru
- Keranjang dan nama pelanggan dipulihkan otomatis dari penyimpanan lokal.
- Simpan transaksi ke riwayat lokal (maksimal 500 transaksi terbaru).
- Pencarian, detail nota, dan penghapusan transaksi.
- Dashboard omzet hari ini, jumlah transaksi, dan akumulasi omzet.
- Ekspor CSV riwayat.
- Backup JSON dan pemulihan dari file JSON.
- Tombol kembali Android menutup modal sebelum keluar dari aplikasi.

## Yang tidak diubah
- Rumus kalkulator pangkat reguler dan Bintang.
- Tarif V, Diamond, Major, dan Bintang pada proyek v5.
- Logo Vyn Store dan aset emblem pangkat.
\n\n## v2.2 — Performance / High Refresh Rate\n- Added an Android preferred refresh-rate request of 144 Hz (subject to device and system policy).\n- Reduced expensive full-screen and per-card backdrop blur effects in the WebView.\n- Disabled the animated, heavily blurred background layer to reduce GPU compositing work.\n- Kept translucent blue glass gradients, highlights, borders, and lightweight button feedback.\n- Removed the explicit WebView hardware-layer override; hardware acceleration remains enabled at the application level.\n