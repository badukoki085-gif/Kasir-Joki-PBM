# Kasir Joki PB — Android Offline (Dark Minimal)

Aplikasi Android offline berbasis WebView untuk kalkulator joki pangkat Point Blank.

## Fitur yang dipertahankan
- Kalkulator pangkat reguler (V, Diamond, Major), mode rentang dan manual
- Kalkulator pangkat bintang berdasarkan EXP
- Keranjang pesanan dan ringkasan total
- Daftar harga
- Nama pembeli, pratinjau nota, dan salin struk

## Tampilan
Tema dark minimalis dengan aksen orange lembut, panel kontras, input yang lebih nyaman disentuh, dan penyesuaian layout untuk layar HP.

## Build APK
Project ini dapat dibuka melalui Android Studio atau dibangun dengan Gradle:

```bash
gradle assembleDebug
```

APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.
Aplikasi memuat `app/src/main/assets/index.html` secara lokal dan tidak memerlukan koneksi internet saat digunakan.


Update v1.4: visual emblem pangkat V, Diamond, Major 1-2, Major 3, dan Bintang mengikuti referensi pengguna. Logika kalkulator dan tarif tidak diubah.
